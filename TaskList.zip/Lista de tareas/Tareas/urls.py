from django.urls import path
from . import views
urlpatterns = [
    path('', views.index , name='nombre_de_la_vista_principal'), #Pagina inicial
    path('Agregar/', views.CrearTareas, name='crear_tarea' ),
    path('eliminar/<int:tarea_id>/', views.eliminar_tarea, name='eliminar_tarea'),
    path('cambiar_estado/<int:tarea_id>/', views.cambiar_estado_tarea, name='cambiar_estado_tarea'),
    path('editar/<int:tarea_id>/' , views.editar , name = 'editar_tarea')
]