from django.db import models

# Las clases que se ocnnvierten en sql van aqui djanog tiene la carpeta migrations para actualiar la base de datos , por lo que o es necesario usar orm
# Codigo en python que se convierte en codigo en sql, funciona como orm
class Tareasarealizar(models.Model):
    Nombre = models.CharField(max_length=200)
class MicroTareas(models.Model):
    Titulo = models.CharField(max_length=200)
    Descripcion = models.CharField(max_length=1000)
    Tareaa = models.ForeignKey(Tareasarealizar, on_delete=models.CASCADE)
# MODELO DE LA LISTA DE TAREAS
class ListadeTareas(models.Model):
    NombreTarea = models.CharField(max_length=200)
    Informacion = models.CharField(max_length=1000)
    Estado =  models.BooleanField(default=False)
    def __str__(self):
        return self.NombreTarea
    def estado_como_texto(self):
        if self.Estado:
            return "Completado"
        else:
            return "No Completado"