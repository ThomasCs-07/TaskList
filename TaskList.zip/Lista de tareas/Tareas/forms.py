from django import forms

class CrearTareasform(forms.Form):
    A1Titulo = forms.CharField(label="Nombre de la tarea nueva ", max_length= 200,  widget=forms.TextInput(attrs={'class': 'form-control'}) )
    A1Descripcion = forms.CharField(label="Informacion o descripcion de la tarea (Opcional)", max_length= 400, widget=forms.TextInput(attrs={'class': 'form-control'}))