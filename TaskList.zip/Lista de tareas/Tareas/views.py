from django.shortcuts import render , redirect
from django.http import HttpResponse
from .models import MicroTareas, ListadeTareas
from django.shortcuts import get_object_or_404, render
from .forms import CrearTareasform 
# Vistas y funciones http   
def mensaje(request):
    Title = 'Welcome to the jungleeee'
    return render(request, 'Agregar_Tarea.html', { 'Tetas' : Title })
def Uso(request, id):
    Micro = get_object_or_404(MicroTareas,id=id)
    #Micro = MicroTareas.objects.get(id=id)
    return HttpResponse('MicroTareas: %s' % Micro.Titulo)
def index(request):
    Titulo = 'TaksList!!'
    Tareas = ListadeTareas.objects.all()
    return render(request, 'Index.html', {'Titulo':Titulo , 'Tareas' : Tareas})
def CrearTareas(request):
    titulo = request.GET.get('A1Titulo', '')
    descripcion = request.GET.get('A1Descripcion', '')
    print(f"Título: {titulo}, Descripción: {descripcion}")
    if titulo == '':
        print('Objeto vacio , no agregar a la lista de tareas')
    else:
        if descripcion == '':
            print('Objeto vacio , no agregar a la lista de tareas')
        else:
            ListadeTareas.objects.create(NombreTarea = titulo , Informacion = descripcion)
    return render(request, 'Agregar_Tarea.html', { 'form' : CrearTareasform()})
def eliminar_tarea(request, tarea_id):
    tarea = get_object_or_404(ListadeTareas, id=tarea_id)
    tarea.delete()
    return redirect('nombre_de_la_vista_principal')
def cambiar_estado_tarea(request, tarea_id):
    tarea = get_object_or_404(ListadeTareas, id=tarea_id)
    tarea.Estado = not tarea.Estado
    tarea.save()
    return redirect('nombre_de_la_vista_principal')
def editar(request, tarea_id):
    tarea = get_object_or_404(ListadeTareas, id=tarea_id)
    print(f"Tarea obtenida: {tarea.NombreTarea}, {tarea.Informacion}, {tarea.Estado}")
    print("INFORMACION INICIAL")
    print(tarea.Informacion)
    if request.method == 'POST':
        tarea.NombreTarea = request.POST.get('Nombre')
        tarea.Informacion = request.POST.get('Descripcion')
        tarea.Estado = request.POST.get('Estado') == 'on' 
        print("___________________________________________________")
        print(tarea.NombreTarea)
        print(tarea.Estado)  
        print(tarea.Informacion)
        tarea.save()
        return redirect('nombre_de_la_vista_principal') 
    return render(request, 'Editar.html', {'tarea': tarea})